import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/api_client.dart';
import '../../state/app_state.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';

class TaskEditorScreen extends StatefulWidget {
  final String projectId;
  const TaskEditorScreen({super.key, required this.projectId});

  @override
  State<TaskEditorScreen> createState() => _TaskEditorScreenState();
}

class _TaskEditorScreenState extends State<TaskEditorScreen> {
  final titleC = TextEditingController();
  final descC = TextEditingController();
  DateTime? due;
  String status = 'todo';
  String? assigneeId;

  Future<void> _save() async {
    final api = ApiClient(token: context.read<AppState>().token);
    await api.createTask(
      projectId: widget.projectId,
      title: titleC.text.trim(),
      description: descC.text.trim().isEmpty ? null : descC.text.trim(),
      assigneeId: assigneeId,
      status: status,
      dueDate: due?.toIso8601String(),
    );
    if (mounted) context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat.yMMMd();
    return Scaffold(
      appBar: AppBar(title: const Text('New Task')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(controller: titleC, decoration: const InputDecoration(labelText: 'Title')),
            const SizedBox(height: 12),
            TextField(controller: descC, maxLines: 4, decoration: const InputDecoration(labelText: 'Description')),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: status,
              items: const [
                DropdownMenuItem(value: 'todo', child: Text('To-Do')),
                DropdownMenuItem(value: 'in_progress', child: Text('In Progress')),
                DropdownMenuItem(value: 'done', child: Text('Done')),
              ],
              onChanged: (v) => setState(() => status = v ?? 'todo'),
              decoration: const InputDecoration(labelText: 'Status'),
            ),
            const SizedBox(height: 12),
            ListTile(
              title: Text(due == null ? 'Pick due date' : 'Due: ${df.format(due!)}'),
              trailing: const Icon(Icons.event),
              onTap: () async {
                final now = DateTime.now();
                final picked = await showDatePicker(
                  context: context,
                  firstDate: now.subtract(const Duration(days: 1)),
                  lastDate: now.add(const Duration(days: 365 * 2)),
                  initialDate: due ?? now,
                );
                if (picked != null) setState(() => due = picked);
              },
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: _save,
                child: const Text('Save'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
